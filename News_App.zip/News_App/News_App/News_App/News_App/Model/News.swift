//
//  News.swift
//  News_App
//
//  Created by Amarzaid on 2/8/21.
//

import SwiftUI

struct News: Identifiable {
    var id = UUID()
    var title : String
    var image : String
    var description : String
}
