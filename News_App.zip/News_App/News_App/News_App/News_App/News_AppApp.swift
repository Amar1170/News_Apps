//
//  News_AppApp.swift
//  News_App
//
//  Created by Amarzaid on 2/8/21.
//

import SwiftUI

@main
struct News_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
